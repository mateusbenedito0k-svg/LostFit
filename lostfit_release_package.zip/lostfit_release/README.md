# LostFit - Release Package (Full-Stack) 🚀

This package includes everything to run, deploy and test the LostFit MVP (frontend + backend).

**Included:**
- `.env.example` (complete placeholders)
- `railway.json` (Railway import template)
- `vercel.env.example` (frontend env example)
- Backend boilerplate: `backend_boilerplate/`
- Frontend scaffold: `repo_ready/`
- Prisma schema and seed script: `backend_boilerplate/prisma/`
- `push_to_github.sh` configured for your repo
- Simulated Prisma migration logs: `prisma_migration_logs/`

## Quick start (local, Docker)
1. Extract the ZIP and open a terminal at the package root.
2. Copy `.env.example` to `.env` and edit values as needed:
   ```bash
   cp .env.example .env
   ```
3. Start services with Docker Compose (Postgres + API):
   ```bash
   docker compose up --build
   ```
4. Run migrations and seed (inside the api container):
   ```bash
   docker compose exec api npx prisma migrate dev --name init
   docker compose exec api node prisma/seed.js
   ```
5. Visit the API: `http://localhost:3333/health`

## Deploy backend to Railway (recommended)
1. Create a Railway account: https://railway.app
2. Import `railway.json` via Railway import UI (New Project → Deploy from JSON)
3. Set environment variables on Railway (Railway will provide DATABASE_URL automatically).
4. Deploy — Railway will build and start the API service. Copy the generated API URL.
5. Update your Vercel frontend variable `VITE_API_URL` with the Railway API URL.

## Deploy frontend to Vercel
1. Push the frontend (`repo_ready/`) to GitHub.
2. On Vercel, create a new project → import from GitHub → select the repo.
3. Add Environment Variables on Vercel:
   - `VITE_API_URL` = `https://<your-railway-api-url>`
4. Deploy and visit `https://lostfit.vercel.app` (or your custom domain).

## GitHub push script
In `repo_ready/`, run the provided script (it will initialize git and push):
```bash
cd repo_ready
./push_to_github.sh git@github.com:mateusbenedito0k-svg/LostFit.git
```

## Simulated Prisma migration & seed logs
Check `prisma_migration_logs/` for example output of `prisma migrate dev` and `node prisma/seed.js` executed in a local environment. These are simulation logs included for reference.

## Notes & Next Steps
- Replace placeholder secrets in `.env` with real keys before production.
- Do not commit real `.env` to public GitHub repos.
- Consider setting up CI (GitHub Actions) and automated deploys on Railway/Vercel.

---
Generated on: 2025-11-05T01:55:16.064435 UTC
