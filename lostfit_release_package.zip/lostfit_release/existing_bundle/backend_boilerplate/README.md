# LostFit Backend Boilerplate

Instructions:
1. Install dependencies: npm install
2. Configure DATABASE_URL in .env (Postgres)
3. Run Prisma migrations: npx prisma migrate dev --name init
4. Start server: npm run dev

Provided endpoints:
- GET /health
- POST /api/auth/signup
- POST /api/auth/login
- GET /api/workouts
- GET /api/meals
