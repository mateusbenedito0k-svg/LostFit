const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main(){
  await prisma.user.create({
    data: {
      name: "Mateus",
      email: "mateus@example.com",
      password: "HASH_PLACEHOLDER",
      age: 28,
      weight: 82,
      height: 1.78,
      goal: "perda de gordura",
      level: "iniciante"
    }
  });

  await prisma.workout.createMany({
    data: [
      { name: "Treino Full Body A", level: "iniciante", duration: 25, calories: 200, exercises: ["agachamento","flexão","prancha"] },
      { name: "Treino Força", level: "intermediário", duration: 40, calories: 350, exercises: ["levantamento terra","supino","remada"] }
    ]
  });

  await prisma.meal.createMany({
    data: [
      { name: "Aveia com banana", calories: 320, ingredients: ["aveia","banana","leite vegetal"] },
      { name: "Salada proteica", calories: 420, ingredients: ["folhas","frango","abacate","castanhas"] }
    ]
  });

  console.log("Seed concluído");
}

main()
  .catch(e => { console.error(e); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });