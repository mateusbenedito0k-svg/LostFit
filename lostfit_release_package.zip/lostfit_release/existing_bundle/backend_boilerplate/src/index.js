const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => res.json({status: 'ok'}));

// Auth routes (placeholders)
app.post('/api/auth/signup', (req, res) => {
  res.json({message: 'signup endpoint - implement'});
});
app.post('/api/auth/login', (req, res) => {
  res.json({message: 'login endpoint - implement'});
});

// Data endpoints
app.get('/api/workouts', (req, res) => {
  res.json([{id:1,name:'Treino Full Body A',level:'iniciante'}]);
});
app.get('/api/meals', (req, res) => {
  res.json([{id:1,name:'Aveia com banana',calories:320}]);
});

const port = process.env.PORT || 3333;
app.listen(port, () => console.log('Server running on', port));
