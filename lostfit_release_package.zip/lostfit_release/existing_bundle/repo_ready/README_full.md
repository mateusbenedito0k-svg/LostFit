
# LostFit - Starter Web Repo

This repo is ready to be pushed to GitHub.

Suggested commands:

git init
git add .
git commit -m "Initial LostFit MVP"
git branch -M main
git remote add origin <YOUR_GITHUB_REPO_URL>
git push -u origin main

Run locally:
cd web
npm install
npm run dev
