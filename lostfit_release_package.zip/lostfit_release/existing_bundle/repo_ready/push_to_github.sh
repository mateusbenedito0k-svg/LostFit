#!/usr/bin/env bash
# push_to_github.sh
# Usage:
# 1) Open terminal
# 2) cd repo_ready
# 3) ./push_to_github.sh YOUR_GITHUB_REPO_URL
# Example:
# ./push_to_github.sh git@github.com:seuuser/lostfit.git

set -e

if [ -z "$1" ]; then
  echo "Usage: ./push_to_github.sh <GIT_REMOTE_URL>"
  exit 1
fi

REMOTE_URL="$1"

echo "Initializing git repository..."
git init
git add .
git commit -m "Initial LostFit MVP"
git branch -M main
git remote add origin "$REMOTE_URL"

echo "Pushing to remote..."
git push -u origin main

echo "Done. Repository pushed to $REMOTE_URL"