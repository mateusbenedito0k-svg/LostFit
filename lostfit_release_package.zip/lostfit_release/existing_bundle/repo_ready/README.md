# LostFit MVP (Web)
This is a minimal scaffold for the LostFit MVP (React + Vite + Tailwind).
Run locally:
1. cd web
2. npm install
3. npm run dev
