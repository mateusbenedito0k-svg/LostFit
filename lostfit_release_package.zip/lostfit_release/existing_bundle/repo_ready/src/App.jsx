import React, {useState} from 'react'

const COLORS = { mint: '#3AF7B3', graphite: '#1C1135' }

function Logo({size=120}) {
  return (
    <svg width={size} height={size} viewBox="0 0 256 256" fill="none" xmlns="http://www.w3.org/2000/svg">
      <g transform="translate(10,10)">
        <path d="M60 20 C80 10,120 10,140 20 C160 30,160 60,140 80 C120 100,90 100,70 80 C50 60,40 30,60 20 Z" stroke={COLORS.mint} strokeWidth="8" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M90 90 C110 110,150 110,160 140" stroke={COLORS.mint} strokeWidth="10" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      </g>
    </svg>
  )
}

export default function App(){
  const [screen, setScreen] = useState(0)
  return (
    <div style={{minHeight:'100vh',background:'#150e2a',display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
      <div style={{width:390,height:780,borderRadius:28,overflow:'hidden',background:COLORS.graphite,padding:18,color:'white',display:'flex',flexDirection:'column'}}>
        <div style={{flex:1,display:'flex',alignItems:'center',justifyContent:'center',flexDirection:'column',gap:20}}>
          {screen===0 && (
            <>
              <Logo />
              <h1 style={{fontSize:28,letterSpacing:2}}>LOSTFIT</h1>
              <button onClick={()=>setScreen(1)} style={{background:COLORS.mint,color:COLORS.graphite,borderRadius:999,padding:'12px 36px',fontWeight:700}}>Começar</button>
            </>
          )}
          {screen===1 && (
            <>
              <div style={{width:'100%',background:'#15102a',borderRadius:16,padding:16}}>
                <div style={{fontSize:36,fontWeight:800}}>2100</div>
                <div style={{opacity:0.7}}>calorias</div>
              </div>
              <div style={{width:'100%',background:'#15102a',borderRadius:16,padding:16,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                <div>
                  <div style={{opacity:0.7}}>Treino do Dia</div>
                  <div style={{fontWeight:700}}>Exercícios • 25 min</div>
                </div>
                <div style={{width:64,height:64,borderRadius:12,border:'1px solid rgba(58,247,179,0.12)',display:'flex',alignItems:'center',justifyContent:'center'}}>
                  <svg width="40" height="40" viewBox="0 0 24 24" fill="none"><path d="M12 2c1.657 0 3 1.343 3 3s-1.343 3-3 3-3-1.343-3-3 1.343-3 3-3z" stroke="#3AF7B3" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /><path d="M6 20c0-3.314 2.686-6 6-6s6 2.686 6 6" stroke="#3AF7B3" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" /></svg>
                </div>
              </div>
              <div style={{marginTop:'auto',display:'flex',justifyContent:'space-around',padding:'12px 0',opacity:0.9}}>
                <div style={{color:'#3AF7B3'}}>Treino</div>
                <div>Nutrição</div>
                <div>Dicas</div>
                <div>Perfil</div>
              </div>
            </>
          )}
          {screen===2 && (
            <>
              <div style={{width:'100%',background:'#15102a',borderRadius:16,padding:16}}>
                <div style={{fontWeight:800,fontSize:18}}>Escolha um treino</div>
              </div>
              <div style={{width:'100%',display:'flex',flexDirection:'column',gap:12}}>
                {['Iniciante','Intermediário','Avançado'].map(l=>(
                  <div key={l} style={{background:'#15102a',padding:12,borderRadius:12,display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                    <div>{l}</div>
                    <div style={{opacity:0.7}}>Ver</div>
                  </div>
                ))}
              </div>
              <div style={{marginTop:'auto',display:'flex',justifyContent:'space-around',padding:'12px 0',opacity:0.9}}>
                <div onClick={()=>setScreen(1)} style={{color:'#3AF7B3',cursor:'pointer'}}>Treino</div>
                <div style={{cursor:'pointer'}}>Nutrição</div>
                <div style={{cursor:'pointer'}}>Dicas</div>
                <div style={{cursor:'pointer'}}>Perfil</div>
              </div>
            </>
          )}
        </div>
        <div style={{display:'flex',gap:8,justifyContent:'center',padding:8}}>
          <button onClick={()=>setScreen(0)} style={{width:10,height:10,borderRadius:999,background: screen===0?'#3AF7B3':'#2a2540'}}></button>
          <button onClick={()=>setScreen(1)} style={{width:10,height:10,borderRadius:999,background: screen===1?'#3AF7B3':'#2a2540'}}></button>
          <button onClick={()=>setScreen(2)} style={{width:10,height:10,borderRadius:999,background: screen===2?'#3AF7B3':'#2a2540'}}></button>
        </div>
      </div>
    </div>
  )
}
