# Figma - Import & Design System Setup (LostFit)

## Import SVG screens
1. Open Figma and create a new file.
2. File → Import → select `01_splash.svg`, `02_home.svg`, `03_trainings.svg`.
3. Place each imported SVG on the canvas.
4. Convert each imported group to a Frame: select → Right-click → Frame Selection (or press F).

## Pages
- Create Pages:
  - 01_Splash
  - 02_Home
  - 03_Treinos
  - Design System
  - Documentation

Move each frame to the respective page.

## Design System (detailed)
1. Colors (create Color Styles):
   - color.mint -> #3AF7B3
   - color.graphite -> #1C1135
   - color.gray-1 -> #CFCFCF
   - color.bg-dark -> #150e2a

2. Typography (create Text Styles):
   - Heading / H1 -> Poppins 32px Bold
   - Heading / H2 -> Poppins 20px Bold
   - Body / Large -> Montserrat 16px Regular
   - Body / Small -> Montserrat 12px Regular

3. Components:
   - Buttons (Variant: Primary / Secondary / Disabled)
   - Cards (Workout Card / Meal Card)
   - Bottom Navigation (4 items with icons)
   - Icon set (create components for each icon)

4. Auto Layout & Spacing:
   - Buttons use Auto Layout: padding 16 horizontal / 12 vertical
   - Card inner padding: 16
   - Standard spacing scale: 8 / 12 / 16 / 24 / 32

5. Create a Documentation page with usage rules and tokens listing.

## Exporting tokens for dev
- In Figma, use Inspect panel to copy color hex and typography.
- Optionally, use plugin: "Tokens Studio" to export tokens as JSON/CSS variables.