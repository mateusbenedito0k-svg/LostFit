#!/usr/bin/env bash
# push_to_github.sh (configured for Mateus' repo)
# Usage:
# ./push_to_github.sh

set -e
REMOTE_URL="git@github.com:mateusbenedito0k-svg/LostFit.git"

if git rev-parse --is-inside-work-tree > /dev/null 2>&1; then
  echo "Repo already initialized. Adding remote and pushing..."
else
  git init
  git add .
  git commit -m "Initial LostFit MVP"
fi

git branch -M main
git remote add origin "$REMOTE_URL" || (git remote set-url origin "$REMOTE_URL")
git push -u origin main
echo "Pushed to $REMOTE_URL"
